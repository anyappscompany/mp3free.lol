<!DOCTYPE html>
<html lang="ru" xml:lang="ru" xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta charset="utf-8">
  <title>[TITLESYMBOL][TITLE]</title>
  <meta name="keywords" content="[KEYWORDS]">
  <meta name="description" content="[DESCRIPTION]">

  <script>
    var arrayOftracks = new Array() ;
  </script>
  <!-- <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400,700" /> -->
  <script async src="http://[SITENAME]/js/ajax.js?[UNIQUE]"></script>

<style>
#ContainerDiv {
  margin: auto;
  position: fixed;
  margin: auto;
  left: 0;
  bottom: 0;
  width: 100%;
}

#InnerContainer {
  width: 100%;
}



#main{

}

body{
  font-family: Helvetica,Arial,sans-serif;
  font-size: 16px;
  color: #333;
line-height: 1.6em;
}
a, a:visited, a:hover, a:active {
    color: #0095DD;
}
a{
  text-decoration: underline;
font-weight: normal;
}
*{
  max-width: 100%;
height: auto;
}
#main input{
  font-size: 32px;
}


#songlist td{
  border-bottom: #BDBDBD 1px solid;
}
.downloadlink, .playlink{
  cursor: pointer;
}
.downloadlink{
  text-decoration: none;
}

.songartist a{
  text-decoration: none;
  color: #333;
  font-size: 14px;
}
.songartist:hover{
  color: #0095DD;
}

.songartist a:hover, a:active{
  text-decoration: none;
  color: #0095DD;
}
.songdurationgenre{
   font-size: 14px;
   color: #808080;
}
p{
  margin: 0px;
}
.playdownload{
  vertical-align: top;
}
.playdownload a{

}
.songtitle{
  font-weight: bold;
}
.songartist span{
  cursor: pointer;
}
.homegenre{
  float: left;
  margin: 2px;
  border: #DCD9D3 1px solid;
  width: 100px;
  height: 120px;
}
.homegenre img{
  width: 70px;
  height: 70px;
}
#header{
font-size: 20px;
font-weight: bold;
}
#topmenu div{
  padding: 3px;
  border: #DCD9D3 1px solid;
  float: left;
  margin-right: 3px;
}
#topmenu .copyrightbtn{
  -moz-box-shadow:inset 0px 1px 0px 0px #54a3f7;
	-webkit-box-shadow:inset 0px 1px 0px 0px #54a3f7;
	box-shadow:inset 0px 1px 0px 0px #54a3f7;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #D30D21), color-stop(1, #0061a7));
	background:-moz-linear-gradient(top, #D30D21 5%, #0061a7 100%);
	background:-webkit-linear-gradient(top, #D30D21 5%, #0061a7 100%);
	background:-o-linear-gradient(top, #D30D21 5%, #0061a7 100%);
	background:-ms-linear-gradient(top, #D30D21 5%, #0061a7 100%);
	background:linear-gradient(to bottom, #D30D21 5%, #0061a7 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#D30D21', endColorstr='#0061a7',GradientType=0);
	background-color:#D30D21;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:3px;
	border:1px solid #124d77;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:13px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #154682;
}

.coloredgenres{
  text-decoration: none;
}
#radiotable td{
border-right: #DCD9D3 1px solid;
}
.titleradio{
  font-weight: bold;
  border-bottom: #DCD9D3 1px solid;
}
#radiotable tr.lineradio:hover{
  background-color: #CFCBC4;
  cursor: pointer;
}
.radiodescription{
  font-size: 10px;
  text-overflow: ellipsis;
overflow: hidden;
width:200px;
height: 20px;
margin: 0px;
}
.lastquery:hover{
background-color: #E8E8E8;
border: #9C9C9C 1px solid;
}
.lastquery{
border: #FFF 1px solid;
}
#h1tag{
  text-transform: capitalize;
}
input[type="text"] {
   text-transform: capitalize;
}

#downloadlink{
  font-size: 36px;
}
.songtitle{
  margin: 0px;
  padding: 0px;
}
.tdowloadlink, .tplaylink{
  background-color: #DBDBDB;
}
a img {
    border: none;
   }
#blockedpagemessage{
  border: #D30D21 5px dashed;
  padding: 10px;
  font-size: 150%;
}

#buttons div{
    width: 29px;
    height: 21px;
    float: left;
    margin: 2px;
    cursor: pointer;
}
/*player*/
#timeline div{
  width: 29px;
    height: 21px;
    float: left;
    margin: 2px;
}
#timelinecontainertd #timecursor{
    width: 40px;
  position: relative;
  height:15px;

  background-color: #999;
  text-align: center;
  padding: 2px;
  color: #fff;
  font-size: 11px;
  cursor: pointer;

  margin: 0px;
  padding: 0px;
  outline: 0;
  font-size: 100%;
  vertical-align: baseline;
}

.repeatsongoff{
    background: url(/players/1/images/replay.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}
.repeatsongon{
    background: url(/players/1/images/replay.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #DBDBDB;
}

.repeatplaylistoff{
    background: url(/players/1/images/replay.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}

.repeatplayliston{
    background: url(/players/1/images/replay.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #DBDBDB;
}

.previoussong{
    background: url(/players/1/images/previous.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}
.randomsong{
    background: url(/players/1/images/random.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}
.nextsong{
    background: url(/players/1/images/next.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}

.stopsong{
  background: url(/players/1/images/stop.png) center no-repeat ;
  background-size: cover;
  width:29px;
  height:21px ;
  background-color: #006FB4;
}

.volumeon{
    background: url(/players/1/images/volume.png) center no-repeat ;
  background-size: cover;
  width:29px;
  height:21px ;
  background-color: #006FB4;
}
.volumeoff{
  background: url(/players/1/images/mute.png) center no-repeat ;
  background-size: cover;
  width:29px;
  height:21px ;
  background-color: #006FB4;
}

#timeline #currenttime, #timeline #durationtime{
  width: 100%;
}
#currenttimetd, #durationtimetd{
  width: 50px;
}

#timeline #timelinecontainer{
  width: 100%;
  background-color: #C5CAE9;
  border: 1px solid #999;
  cursor: pointer;
  height:15px;

  margin: 0;
  padding: 0;
  outline: 0;
  font-size: 100%;
  vertical-align: baseline;

}
#timeline{
  color: #C5CAE9;
}

.playpauseoff{
    background: url(/players/1/images/play.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}

.playpauseon{
    background: url(/players/1/images/pause.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #DBDBDB;
}

.playpaudefault{
    background: url(/players/1/images/play.png) center no-repeat ;
    background-size: cover;
    width:29px;
    height:21px ;
    background-color: #006FB4;
}

#songnavigation{
  font-size:10px;
}
#songnavigation div{
  white-space: nowrap; /* Отменяем перенос текста */
    overflow: hidden; /* Обрезаем содержимое */
    background: #DBDBDB;
    cursor: pointer;
}

#volumecontrol #volumecontrolcontainer{
  width: 100%;
  background-color: #C5CAE9;
  border: 1px solid #999;
  cursor: pointer;
  height:15px;

  margin: 0;
  padding: 0;
  outline: 0;
  font-size: 100%;
  vertical-align: baseline;
}

#volumecontrolcontainertd #volumecursor{
    width: 40px;
  position: relative;
  height:15px;

  background-color: #999;
  text-align: center;
  padding: 2px;
  color: #fff;
  font-size: 11px;
  cursor: pointer;

  margin: 0px;
  padding: 0px;
  outline: 0;
  font-size: 100%;
  vertical-align: baseline;
}
#playerstyle{
  background-color: #212121;
}
#nextsongtd{
  width: 200px;
}
#prevsongtd{
  width: 200px;
}
#songnavigation{
  width: 100%;
}
#timecont{
  width: 100%;
}
#volcont{
  width: 100%;
}
#playerstyle{
 position: fixed;
 bottom:0;
 width: 100%;
 border: 5px solid gray;
}
#songlist{
  width: 100%;
}
</style>

<script>
//player
function updateSource(songnum){      
//var playertracknamecont = document.getElementById('playertrackname');
//playertracknamecont.innerHTML = document.getElementById('song'+songnum).getAttribute('data-track');

var audio = document.getElementById('audio-player');

audio.src=document.getElementById('song'+songnum).getAttribute('data-value');

audio.load();
audio.play();

var clickedlink = document.getElementById('p'+songnum);
clickedlink.style.color = '#212121';

var allplaylinks = document.getElementsByClassName('playlink');
for(var i = 0; i< allplaylinks.length; i++){
  if(allplaylinks[i].id == 'p'+songnum)continue;
  allplaylinks[i].style.color = '#0095DD';
}

}

// radio
function playradio(source, id){
  var audio = document.getElementById('audio-player');
audio.src=source;
//audio.load();
audio.play();

var selectedtr = document.getElementById(id);
selectedtr.style.backgroundColor = '#0095DD';

var alltrlinks = document.getElementsByClassName('lineradio');
for(var i = 0; i< alltrlinks.length; i++){
  if(alltrlinks[i].id == id)continue;
  alltrlinks[i].style.backgroundColor = '#FFFFFF';
}

}


document.onkeyup = function (e) {
	    e = e || window.event;
	    if (e.keyCode === 13) {
	        console.log('cc');
	    }
	    return false;
	}
</script>
<meta name="geo.region" content="[GEOREGION]" />
<meta name="geo.placename" content="[GEOPLACENAME]" />
<meta name="geo.position" content="[GEOPOSITION]" />
<meta name="ICBM" content="[GEOICBM]" />
<link rel="SHORTCUT ICON" href="favicon.ico" type="image/x-icon" />




<style>


.formdownload, .playlink {
  float: left;
  text-decoration: none;
}
.formdownload{
  margin: 0px;
  padding: 0px;
  display: inline;
}

</style>

<style>
  .topmenu {
	-moz-box-shadow:inset 0px 1px 0px 0px #54a3f7;
	-webkit-box-shadow:inset 0px 1px 0px 0px #54a3f7;
	box-shadow:inset 0px 1px 0px 0px #54a3f7;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #007dc1), color-stop(1, #0061a7));
	background:-moz-linear-gradient(top, #007dc1 5%, #0061a7 100%);
	background:-webkit-linear-gradient(top, #007dc1 5%, #0061a7 100%);
	background:-o-linear-gradient(top, #007dc1 5%, #0061a7 100%);
	background:-ms-linear-gradient(top, #007dc1 5%, #0061a7 100%);
	background:linear-gradient(to bottom, #007dc1 5%, #0061a7 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#007dc1', endColorstr='#0061a7',GradientType=0);
	background-color:#007dc1;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:3px;
	border:1px solid #124d77;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:13px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #154682;
}


.topmenu:hover {
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #0061a7), color-stop(1, #007dc1));
	background:-moz-linear-gradient(top, #0061a7 5%, #007dc1 100%);
	background:-webkit-linear-gradient(top, #0061a7 5%, #007dc1 100%);
	background:-o-linear-gradient(top, #0061a7 5%, #007dc1 100%);
	background:-ms-linear-gradient(top, #0061a7 5%, #007dc1 100%);
	background:linear-gradient(to bottom, #0061a7 5%, #007dc1 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#0061a7', endColorstr='#007dc1',GradientType=0);
	background-color:#0061a7;
}
.topmenu:active {
	position:relative;
	top:1px;
}
#topmenu a{
  color: #FFFFFF;
}

.oneitem button {
     background:none!important;
     border:none;
     padding:0!important;
     font: inherit;
     /*border is optional*/
     /*border-bottom:1px solid #0095DD;*/
     cursor: pointer;
     color: #0095DD;
font-weight: normal;
}
#main{
  margin-bottom: 130px;
  width: 100%;

}
#quantcast{
border: #CC0000 1px solid;

}
#headimg{
  width: 80px;
}
#playimg{
  width: 20px;
}
#downloadimg{
  width: 20px;
}
#firstletter a{
 margin: 5px;
 padding: 1px;
 font-size: 20px;
 line-height: 40px;
}
#musicmp3{
width: 100%;
}
.wwrap {
	white-space: pre;           /* CSS 2.0 */
	white-space: pre-wrap;      /* CSS 2.1 */
	white-space: pre-line;      /* CSS 3.0 */
	white-space: -pre-wrap;     /* Opera 4-6 */
	white-space: -o-pre-wrap;   /* Opera 7 */
	white-space: -moz-pre-wrap; /* Mozilla */
	white-space: -hp-pre-wrap;  /* HP Printers */
	word-wrap: break-word;      /* IE 5+ */
}
  </style>

<meta name="viewport" content="width=device-width">
<meta name="MobileOptimized" content="320"/>
<meta name="HandheldFriendly" content="true"/>

</head>

<body>

<table id="main" >
<tr>
    <td id="header">[HEADER]&nbsp;<a href="http://[SITENAME]/rss.php"><img src="images/rss_icon.png" alt="" /></a></td>
</tr>
<tr>
    <td id="topmenu">
        <div><a class="topmenu" href="http://[SITENAME]">[HOME]</a></div> <div><a class="topmenu" href="http://[SITENAME]/playlists">[PLAYLISTS]</a></div> <div><a class="topmenu" href="http://[SITENAME]/songsbygenre">[SONGSBYGENRE]</a></div> <div><a class="topmenu" href="http://[SITENAME]/hits100">[HITS100]</a></div> <div><a class="topmenu" href="http://[SITENAME]/radio">[RADIO]</a></div> <div><a class="topmenu" href="http://[SITENAME]/contacts">[CONTACTS]</a></div> <div><a class="copyrightbtn" href="http://[SITENAME]/copyright">[COPYRIGHT]</a></div>
    </td>
</tr>
<tr>
    <td>[TEXT1]<br /><table width="100%"><tr><td>
        <input placeholder="[PLACEHOLDER]" autofocus type="text" id="musicmp3" name="musicmp3" value="[CURRENTSEARCH]"></td><td>
        <input id="searchButton" name="searchButton" type="button" value="Поиск" onclick="startSearch(0);"></td></tr></table>
    </td>
</tr>
<tr>
    <td id="firstletter">
        <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=а'>А</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=б'>Б</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=в'>В</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=г'>Г</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=д'>Д</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=е'>Е</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=ж'>Ж</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=з'>З</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=и'>И</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=й'>Й</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=к'>К</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=л'>Л</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=м'>М</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=н'>Н</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=о'>О</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=п'>П</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=р'>Р</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=с'>С</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=т'>Т</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=у'>У</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=ф'>Ф</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=х'>Х</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=ц'>Ц</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=ч'>Ч</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=ш'>Ш</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=э'>Э</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=ю'>Ю</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=я'>Я</a>
        <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=0'>0</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=1'>1</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=2'>2</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=3'>3</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=4'>4</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=5'>5</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=6'>6</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=7'>7</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=8'>8</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=9'>9</a>
        <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=a'>A</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=b'>B</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=c'>C</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=d'>D</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=e'>E</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=f'>F</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=g'>G</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=h'>H</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=i'>I</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=j'>J</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=k'>K</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=l'>L</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=m'>M</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=n'>N</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=o'>O</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=p'>P</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=q'>Q</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=r'>R</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=s'>S</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=t'>T</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=u'>U</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=v'>V</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=w'>W</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=x'>X</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=y'>Y</a> <a href='http://[SITENAME]/index.php?action=firstletter&amp;letter=z'>Z</a>

    </td>
</tr>
<tr>
    <td >
        <div id="resultSearchMusic"></div>
            <h1 id='h1tag'>[H1TAG]</h1>
            <!-- [SOCIALNETWORKS]<br /> -->
            [CONTENT]
    </td>
</tr>
<tr>
    <td>
    [COMMENTS]
    </td>
</tr>
<tr>
    <td>

    [LASTQUERIESTEXT][LASTQUERIES]
    </td>
</tr>
<tr>
    <td>
        <div itemscope itemtype="http://schema.org/Organization">
   <span itemprop="name">[ORGANIZATIONNAME]</span><br />
   [ORGANIZATIONLOCATION]
   <div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
      <span itemprop="streetAddress">[STREETADDRESS]</span>,
      <span itemprop="addressLocality">[ADDRESSLOCALITY]</span>,
      <span itemprop="addressRegion">[ADDRESSREGION]</span>.
   </div>
  <img alt="[SITENAME]" itemprop="logo" src="http://[SITENAME]/images/mp3.png" /><br />
   [PHONE] <span itemprop="telephone">[PHONENUMBER]</span><br />
   <a href="http://[SITENAME]" itemprop="url">http://[SITENAME]</a>
   <a href="http://[SITENAME]/rss.php"><img src="images/rss_icon.png" alt="" /></a>
</div>
<!-- <noindex> --><script type="text/javascript"><!--
document.write("<a rel='nofollow' href='//www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t45.11;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet' "+
"border='0' width='31' height='31'><\/a>")
//--></script><!-- </noindex> -->

<!-- Quantcast Tag -->
<script type="text/javascript">
var _qevents = _qevents || [];

(function() {
var elem = document.createElement('script');
elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";
elem.async = true;
elem.type = "text/javascript";
var scpt = document.getElementsByTagName('script')[0];
scpt.parentNode.insertBefore(elem, scpt);
})();

_qevents.push({
qacct:"p-W1_Urmc_cjjvj"
});
</script>

<noscript>
<div style="display:none;">
<img alt="quantcast" id="quantcast" src="//pixel.quantserve.com/pixel/p-W1_Urmc_cjjvj.gif" />
</div>
</noscript>
<!-- End Quantcast tag -->
    </td>
</tr>

</table>
<div id="ContainerDiv">
    <div id="InnerContainer">
        <div id="TheBelowDiv">


        <!--<div id="player">
  <div id="mmargin">-->
  <audio id="audio-player">
    <p>Your browser does not support the audio element </p>
  </audio>

  <!--<div id="volume"></div>
  <div id="progressbar"></div>
  <div id="playpause"></div>
</div>
</div>-->
[PLAYERCODE]

    </div>
    </div>
</div>
        <!--<p id="playertrackname">&nbsp;</p>-->
<!-- player -->


<!-- /player -->
<!-- Yandex.Metrika counter --><script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter30779098 = new Ya.Metrika({ id:30779098, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true, trackHash:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks");</script><noscript><div><img src="https://mc.yandex.ru/watch/30779098" style="position:absolute; left:-9999px;" alt="" /></div></noscript><!-- /Yandex.Metrika counter -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-16758892-1', 'auto');
  ga('send', 'pageview');

</script>
</body>

</html>