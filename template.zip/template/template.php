<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head>
    <meta charset="utf-8">
    <title>[TITLE]</title>
    <meta name="keywords" content="[KEYWORDS]">
    <meta name="description" content="[DESCRIPTION]">
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">




    <link rel="shortcut icon" href="/template/favicon.ico" type="image/x-icon">
    <script>
    var stat = false;
    var prevsel = 0;
    function play(id){

    var allplaylinks = document.getElementsByClassName('red-player');
    var audio = document.getElementById('audio-player');



    for(var i = 0; i< allplaylinks.length; i++){
        if(allplaylinks[i].id=="p"+id){
            if(getPos(i)=="0px 0px"){allplaylinks[i].style.backgroundPosition = '-60px 0px';
            console.log("play "+i);
            audio.src=document.getElementById('p'+id).getAttribute('data-value');
            audio.volume = 1.0;
            audio.load();
            audio.play();
            }
            else if(getPos(i)=="-60px 0px"){allplaylinks[i].style.backgroundPosition = '0px 0px';
            console.log("stop "+i);
            audio.pause();
            audio.currentTime = 0;
            }
            continue;
        }
            allplaylinks[i].style.backgroundPosition = '0px 0px';
            }
    }



    function getPos(_i){
        var allplaylinks = document.getElementsByClassName('red-player');
        _tmp = window.getComputedStyle(allplaylinks[_i],null).backgroundPosition.trim().split(/\s+/),
    positions = {
        'left' : _tmp[0],
        'top' : _tmp[1]
    };
return positions.left+ " "+ positions.top;
    }


    </script>


<style>.mp3freelol-content .mp3freelol-postcontent-0 .layout-item-0 { padding-right: 0px;padding-left: 0px;  }
.ie7 .mp3freelol-post .mp3freelol-layout-cell {border:none !important; padding:0 !important; }
.ie6 .mp3freelol-post .mp3freelol-layout-cell {border:none !important; padding:0 !important; }
@media (max-width: 469px) {
    .artitcont{
 max-width:100px;
 white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
}
@media (max-width: 321px) {
    .artitcont{
 max-width:70px;
 white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.dur, .genre, #durationcol, #genrecol{
    display: none;
}
.artitcont{
    max-width: 150px;
    }
}

@media (max-width: 296px) {
    .artitcont{
 max-wid    0px;
 white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.dur, .genre, #durationcol, #genrecol{
    display: none;
}
.artitcont{
    max-width: 150px;
    }
}
@media (max-width: 241px) {
    .artitcont{
 max-width:70px;
 white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.dur, .genre, #durationcol, #genrecol{
    display: none;
}
.artitcont{
    max-width: 100px;
    }
}
#playlist tr:hover{
    background: #434343;
}
#recentsearches{
    display: inline;
    word-break: break-all;
}

#downloadlink, #prevpage{
  cursor: pointer;
  text-decoration: none;
  font-size: 180%;
}

</style>
<script async src="http://[SITENAME]/js/ajax.js?[UNIQUE]"></script>
</head>
<body>
<div id="mp3freelol-main">
    <div id="mp3freelol-header-bg">
            </div>
    <div class="mp3freelol-sheet clearfix">
<header class="mp3freelol-header">

    <div class="mp3freelol-shapes">

            </div>

<h1 class="mp3freelol-headline">
    <a href="/">[HEADLINE]</a>
</h1>
<h2 class="mp3freelol-slogan">[SLOGAN]</h2>





<nav class="mp3freelol-nav">
    <ul class="mp3freelol-hmenu"><li><a href="http://[SITENAME]">[HOME]</a></li><li><a href="http://[SITENAME]/genres">[SONGSBYGENRE]</a></li><li><a href="http://[SITENAME]/top100songs">[HITS100]</a></li><li><a href="http://[SITENAME]/radio">[RADIO]</a></li><li><a href="http://[SITENAME]/contacts">[CONTACTS]</a></li><li><a href="http://[SITENAME]/copyright">[COPYRIGHT]</a></li></ul>
    </nav>


</header>
<div class="mp3freelol-layout-wrapper">
                <div class="mp3freelol-content-layout">
                    <div class="mp3freelol-content-layout-row">
                        <div class="mp3freelol-layout-cell mp3freelol-content"><div class="mp3freelol-block clearfix">
        <div class="mp3freelol-blockcontent"><form onsubmit="startSearch(0);return false;" class="mp3freelol-search" name="search" action="#" id="search"><input id="musicmp3" name="musicmp3" placeholder="[PLACEHOLDER]" type="text" value="[CURRENTSEARCH]"><a class="mp3freelol-search-button" id="searchButton" name="searchButton" onclick="startSearch(0);"><span class="mp3freelol-search-button-text">[SEARCHBUTTONTEXT]</span></a></form></div>
</div><div class="mp3freelol-block clearfix"><div id="resultSearchMusic"></div>
        <div class="mp3freelol-blockcontent"><p>additional block</p></div>
</div><article class="mp3freelol-post mp3freelol-article">
                                <h1 id='h1tag'>[H1TAG]</h1>

                <div class="mp3freelol-postcontent mp3freelol-postcontent-0 clearfix"><div class="mp3freelol-content-layout">
    <div class="mp3freelol-content-layout-row">
    <div class="mp3freelol-layout-cell layout-item-0" style="width: 100%" >
    [CONTENT]
    </div>
    </div>
</div>
</div>


</article><div class="mp3freelol-block clearfix">
        <div class="mp3freelol-blockcontent"><ul class="menu-inline">
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=0">0</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=1">1</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=2">2</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=3">3</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=4">4</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=5">5</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=6">6</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=7">7</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=8">8</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=9">9</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=A">A</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=B">B</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=C">C</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=D">D</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=E">E</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=F">F</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=G">G</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=H">H</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=I">I</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=J">J</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=K">K</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=L">L</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=M">M</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=N">N</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=O">O</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=P">P</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=Q">Q</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=R">R</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=S">S</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=T">T</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=U">U</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=V">V</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=W">W</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=X">X</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=Y">Y</a>
			</li>
			<li>
						<a href="http://[SITENAME]/index.php?filter=a_z&amp;letter=Z">Z</a>
			</li>
		</ul></div>
</div></div>
                        <div class="mp3freelol-layout-cell mp3freelol-sidebar1"><div class="mp3freelol-block clearfix">
        <div class="mp3freelol-blockcontent"><p>additional block</p></div>
</div><div class="mp3freelol-block clearfix">
        <div class="mp3freelol-blockcontent"><p>[LASTQUERIESTEXT]</p>
<p id="recentsearches">
[LASTQUERIES]
</p></div>
</div></div>
                    </div>
                </div>
            </div><footer class="mp3freelol-footer">
<p><a href="http://[SITENAME]/rss.php">RSS</a> <a href="http://[SITENAME]/lasturls.php?links=true">Latest Songs</a></p>
<p>Copyright © 2015. All Rights Reserved.</p>
</footer>

    </div>
</div>

<audio id="audio-player" volume="1.0" loop="loop">
    <p>Your browser does not support the audio element </p>
</audio>
<!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="/template/style.css" media="screen">
    <!--[if lte IE 7]><link rel="/template/stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="/template/style.responsive.css" media="all">


<script src="/template/jquery.js"></script>
    <script src="/template/script.js"></script>
    <script src="/template/script.responsive.js"></script>

    <!-- Yandex.Metrika counter --><script type="text/javascript"> (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter32597875 = new Ya.Metrika({ id:32597875, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks");</script><noscript><div><img src="https://mc.yandex.ru/watch/32597875" style="position:absolute; left:-9999px;" alt="" /></div></noscript><!-- /Yandex.Metrika counter -->

<!-- PopAds.net Popunder Code for mp3free.lol -->
<script type="text/javascript">
  var _pop = _pop || [];
  _pop.push(['siteId', 986060]);
  _pop.push(['minBid', 0.000000]);
  _pop.push(['popundersPerIP', 0]);
  _pop.push(['delayBetween', 0]);
  _pop.push(['default', false]);
  _pop.push(['defaultPerDay', 0]);
  _pop.push(['topmostLayer', false]);
  (function() {
    var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.async = true;
    var s = document.getElementsByTagName('script')[0];
    pa.src = '//c1.popads.net/pop.js';
    pa.onerror = function() {
      var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
      sa.src = '//c2.popads.net/pop.js';
      s.parentNode.insertBefore(sa, s);
    };
    s.parentNode.insertBefore(pa, s);
  })();
</script>
<!-- PopAds.net Popunder Code End -->    
</body></html>