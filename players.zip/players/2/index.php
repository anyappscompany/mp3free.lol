<!-- player -->
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<style>
#player{
  position:relative;
  margin:10px auto;
  width:95%;
  text-align:center;
  font-family:Helvetica, Arial;
  border:5px solid #212121;
  background: #FFFFFF;
}


#playpause{
  border:1px solid #eee;
  cursor:pointer;
  padding:4px 0;
  color:#888;
  font-size:12px;
  border-radius:3px;
}
#playpause:hover{
  border-color: #ccc;
}
#volume, #progressbar{
  border:none;
  height:12px;
}
#volume{
  background:hsla(214, 62%, 65%, 1);
}
#progressbar{
  background:#ccc;
}
.ui-slider-handle{
  border-radius:50%;
  top: -5px !important;
  width: 21px !important;
  height: 21px !important;
  margin-left:-5px !important;
}
#mmargin{
  margin: 15px;
}
#player div{
  margin-bottom: 8px;
}


</style>
<script>
$(function() {

  var $aud = $("#audio-player"),
      $pp  = $('#playpause'),
      $vol = $('#volume'),
      $bar = $("#progressbar"),
      AUDIO= $aud[0];

  AUDIO.volume = 0.5;
  AUDIO.addEventListener("timeupdate", progress, false);

  function getTime(t) {
    var m=~~(t/60), s=~~(t % 60);
    return (m<10?"0"+m:m)+':'+(s<10?"0"+s:s);
  }

  function progress() {
    $bar.slider('value', ~~(100/AUDIO.duration*AUDIO.currentTime));
    $pp.text(getTime(AUDIO.currentTime));
  }

  $vol.slider( {
    value : AUDIO.volume*100,
    slide : function(ev, ui) {
      $vol.css({background:"hsla(214,"+ui.value+"%,65%,1)"});
      AUDIO.volume = ui.value/100;
    }
  });

  $bar.slider( {
    value : AUDIO.currentTime,
    slide : function(ev, ui) {
      AUDIO.currentTime = AUDIO.duration/100*ui.value;
    }
  });

  $pp.click(function() {
    return AUDIO[AUDIO.paused?'play':'pause']();
  });

});


</script>