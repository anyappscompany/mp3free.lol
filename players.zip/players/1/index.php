<script>
    var audio = document.getElementById('audio-player');
    var currentTrack = 0;
    var volumeSwitcher = true;
    var playpauseSwitcher = true;

    var repeatSongSwitcher = false;
    var repeatPlaylistSwitcher = false;

    /**********************/
    function repeatSongSwitch() {
      repeatSongSwitcher = repeatSongSwitcher ? false : true;
      var repeatsongdiv = document.getElementById('repeatsong');
      if(repeatSongSwitcher){
        repeatsongdiv.className.replace('repeatsongoff', '');
        repeatsongdiv.className = "repeatsongon";
      }else{
        repeatsongdiv.className.replace('repeatsongon', '');
        repeatsongdiv.className = "repeatsongoff";
      }
      };
    /**********************/
    function repeatPlaylistSwitch() {
      repeatPlaylistSwitcher = repeatPlaylistSwitcher ? false : true;
      var repeatplaylistdiv = document.getElementById('repeatplaylist');
      if(repeatPlaylistSwitcher){
        repeatplaylistdiv.className.replace('repeatplaylistoff', '');
        repeatplaylistdiv.className = "repeatplayliston";
      }else{
        repeatplaylistdiv.className.replace('repeatplayliston', '');
        repeatplaylistdiv.className = "repeatplaylistoff";
      }
      };
    /**********************/
    function play(){
      audio.src = arrayOftracks[currentTrack][0];
      audio.load();
      audio.play();
      //updateDuration();
      var playpauseswitcherdiv = document.getElementById('playpausesong');
      playpauseswitcherdiv.className.replace('playpaudefault', '');
      playpauseswitcherdiv.className = "playpauseon";

      // подсветка активного
      // подсветка активного
         highlightActive();


    }
    /***********************/
    function highlightActive(){
      var clickedlink = document.getElementById('p'+(currentTrack+1));
      clickedlink.style.color = '#212121';
      var allplaylinks = document.getElementsByClassName('playlink');
for(var i = 0; i< allplaylinks.length; i++){
  if(allplaylinks[i].id == 'p'+(currentTrack+1))continue;
  allplaylinks[i].style.color = '#0095DD';
}
    }
    /**********************/
    function setSongNavigation(){
      /*
      <td id="prevsongtd"><div id="prevsongdiv" class="" title=""></div></td>
                    <td id="cursongtd"><div id="cursongdiv" class="" title=""></div></td>
                    <td id="nextsongtd"><div id="nextsongdiv" class="" title=""></div></td>*/
      var prevsongdiv =  document.getElementById('prevsongdiv');
      var cursongdiv =  document.getElementById('cursongdiv');
      var nextsongdiv =  document.getElementById('nextsongdiv');

      var prevtrack = currentTrack-1;
        if(prevtrack<0){
          prevsongdiv.innerHTML = "";
        }else{
          prevsongdiv.innerHTML = decodeURIComponent(arrayOftracks[prevtrack][2].replace(/[\u002B]/g,' ')+" - "+arrayOftracks[prevtrack][1].replace(/[\u002B]/g,' '));
          prevsongdiv.setAttribute('onclick','--currentTrack;playpauseSwitcher = false;play();');
          //--currentTrack;play();
        }
      var curtrack = currentTrack;
        cursongdiv.innerHTML = decodeURIComponent(arrayOftracks[curtrack][2].replace(/[\u002B]/g,' ')+" - "+arrayOftracks[curtrack][1].replace(/[\u002B]/g,' '));
        cursongdiv.setAttribute('onclick','playpauseSwitcher = false;play();');
      var nexttrack = currentTrack+1;
        if(nexttrack>=arrayOftracks.length){
          nextsongdiv.innerHTML = "";
        }else{
          nextsongdiv.innerHTML = decodeURIComponent(arrayOftracks[nexttrack][2].replace(/[\u002B]/g,' ')+" - "+arrayOftracks[nexttrack][1].replace(/[\u002B]/g,' '));
          nextsongdiv.setAttribute('onclick','++currentTrack;playpauseSwitcher = false;play();');
          //nextsongdiv.setAttribute('onclick','updateSource('+arrayOftracks[nexttrack][3]+');');
        }
      //prevsongdiv.innerHTML = arrayOftracks[prevtrack][2]+" - "+arrayOftracks[prevtrack][1];


    }
    /**********************/
    document.addEventListener('DOMContentLoaded',function(){
      Elements = document.getElementsByClassName("playlink");
      for(var i=0; i<Elements.length; i++) {
        Elements[i].onclick = startSong;
        }


        //установка курсора звука в конец
          //var volumecursor = document.getElementById('volumecursor');
      //var volumecursorwidth = 0;
      //volumecursorwidth = volumecursor.offsetWidth;
      var volumecontrolcontainer = document.getElementById('volumecontrolcontainer');
progresswidth = volumecontrolcontainer.offsetWidth;

      volumecursor.style.left =progresswidth/2+'px';
      audio.volume = 0.5;


      });
     audio.addEventListener("ended",function() {
        //console.log('ended');
        var playpauseswitcherdiv = document.getElementById('playpausesong');
        playpauseswitcherdiv.className.replace('playpauseon', '');
        playpauseswitcherdiv.className = "playpauseoff";
        //repeatSongSwitcher
        nextSong();
    });


    /**********************/
    audio.addEventListener("playing",function() {
        //console.log("length:"+arrayOftracks.length+" current:"+(currentTrack+1));
        setSongNavigation();
    });
    /**********************/
    function formatTime(time) {
      var
       minutes = Math.floor(time / 60) % 60,
    seconds = Math.floor(time % 60);

  return   (minutes < 10 ? '0' + minutes : minutes) + ':' + (seconds < 10 ? '0' + seconds : seconds);
           }
    /**********************/
    function updateDuration(){
      var songDuration = document.getElementById('durationtime');
      var locDuration = 0;
      //songDuration.innerHTML = audio.duration;
      if (audio.duration) {
        locDuration = audio.duration;
        } else {
          audio.onloadedmetadata = function() {
            locDuration = audio.duration;
            }
          } //locDuration = arrayOftracks[currentTrack][4]
          songDuration.innerHTML = formatTime(locDuration);
        }

        audio.addEventListener("loadedmetadata",function() {
          updateDuration();
    });















    /**********************/
    function updateTime(){
      var songCurrentTime = document.getElementById('currenttime');
      songCurrentTime.innerHTML = formatTime(audio.currentTime);
    }
    audio.addEventListener("timeupdate",function() {
          updateTime();
          /*движение*/
          var locDuration = 0;
          var step = 0;
          var progresswidth = 0;
          var timelinecontainer = document.getElementById('timelinecontainer');
          var timecursor = document.getElementById('timecursor');
          var timecursorwidth = 0;
      timecursorwidth = timecursor.offsetWidth;

           if (audio.duration)
           {
             locDuration = audio.duration;
             } else {
               audio.onloadedmetadata = function() {
                 locDuration = audio.duration;
             }
           } //locDuration = arrayOftracks[currentTrack][4];

           progresswidth = timelinecontainer.offsetWidth;
           step = progresswidth/locDuration;     console.log(progresswidth+"/"+locDuration+"="+step);
           //console.log(locDuration+':'+audio.currentTime);
           if((audio.currentTime*step)>=(progresswidth-timecursorwidth)){
             timecursor.style.left = progresswidth-timecursorwidth+'px';
             return;
             }
           timecursor.style.left = audio.currentTime*step+'px';
    });

    /*-------------------------*/
    function stopSong(){
      if(!audio.paused){ // если играется трек, то остановить
        audio.pause();
        audio.currentTime = 0.0;
        var playpauseswitcherdiv = document.getElementById('playpausesong');
        playpauseswitcherdiv.className.replace('playpauseon', '');
        playpauseswitcherdiv.className = "playpauseoff";
        playpauseSwitcher = true; // истина, если пауза
      }
    }

    function previousSong(){
      var songcount = arrayOftracks.length;
      //console.log("CUR:"+currentTrack);
      --currentTrack;
      if(currentTrack<0){
        currentTrack = 0;
      }
      playpauseSwitcher = false; // ложь, если играет трек
      play();
    }

    function nextSong(){
      var songcount = arrayOftracks.length;
      //console.log("CUR:"+currentTrack);
      if(!repeatSongSwitcher){
      ++currentTrack;
      }
      if(currentTrack>(arrayOftracks.length-1)){
        currentTrack = arrayOftracks.length-1;

        if(repeatPlaylistSwitcher){currentTrack=0;}
      }

      playpauseSwitcher = false;
      play();
    }

    function startSong(e){ // выбор в плейлисте
      var target = e.target;
      var trackid = target.id.substr(1);
      //console.log(trackid);

      currentTrack = trackid-1;
      playpauseSwitcher = false;
      play();
      //console.log("Трек:"+currentTrack);
      //audio.src=document.getElementById('song'+trackid).getAttribute('data-value');

    }

    function randomSong(){
      currentTrack = getRandomInt(0, arrayOftracks.length-1);
      playpauseSwitcher = false;
      play();
      //arrayOftracks.length
    }


function getRandomInt(min, max)
{
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

    function volumeSwitch(){
      volumeSwitcher = volumeSwitcher ? false : true;
      var volumeswitcherdiv = document.getElementById('volumesong');
      if(volumeSwitcher){
        volumeswitcherdiv.className.replace('volumeoff', '');
        volumeswitcherdiv.className = "volumeon";
        audio.muted = false;
      }else{
        volumeswitcherdiv.className.replace('volumeon', '');
        volumeswitcherdiv.className = "volumeoff";
        audio.muted = true;
      }
    }

    function playpauseSwitch(){
     var playpauseswitcherdiv = document.getElementById('playpausesong');

      var locDuration = 0;
      //songDuration.innerHTML = audio.duration;
      if (audio.duration) {
        locDuration = audio.duration;
        } else {
          audio.onloadedmetadata = function() {
            locDuration = audio.duration;
            }
          }

      if(playpauseSwitcher){
        playpauseswitcherdiv.className.replace('playpauseoff', '');
        playpauseswitcherdiv.className = "playpauseon";

        if(locDuration>0){ // после паузы
        audio.play();
        }else{ // новый play
         audio.src = arrayOftracks[currentTrack][0];
         audio.load();
         audio.play();

         // подсветка активного
         highlightActive();



        }
      }else{
        playpauseswitcherdiv.className.replace('playpauseon', '');
        playpauseswitcherdiv.className = "playpauseoff";
        audio.pause();
      }
      playpauseSwitcher = playpauseSwitcher ? false : true;
      //}
    }

    /*document.addEventListener("DOMContentLoaded", ready);
    var x="";
    var y="";
    function ready(){
      var timelinecontainer = document.getElementById('timelinecontainer');
       x = timelinecontainer.offsetX==undefined?timelinecontainer.layerX:timelinecontainer.offsetX;
       y = timelinecontainer.offsetY==undefined?timelinecontainer.layerY:timelinecontainer.offsetY;
    }*/
    function changePosition(e, obj){
      if (window.event && !e) e=window.event;
      var ref=e.target||e.srcElement;

       var locDuration = 0;
      if (audio.duration) {
        locDuration = audio.duration;
        } else {
          audio.onloadedmetadata = function() {
            locDuration = audio.duration;
            }
          }    //locDuration = arrayOftracks[currentTrack][4];
          if(locDuration<=0)return; // не двигать курсор, если не загружен трек
       //var e = window.event;
       //e.target = e.srcElement;
       var x = e.offsetX==undefined?e.layerX:e.offsetX;
       var y = e.offsetY==undefined?e.layerY:e.offsetY;

      var timecursor = document.getElementById('timecursor');
      var timecursorwidth = 0;
      timecursorwidth = timecursor.offsetWidth;

      var progresswidth = 0;
var timelinecontainer = document.getElementById('timelinecontainer');
progresswidth = timelinecontainer.offsetWidth;
      console.log("ширина полоски: "+progresswidth+" ширина курсора: "+timecursorwidth+"позиция клика: "+x);

      if((x-timecursorwidth)<0){
        x=0;timecursor.style.left = x+'px';
        }else if((x+timecursorwidth)>=progresswidth){
          x=progresswidth-timecursorwidth;
          timecursor.style.left = x+'px';
          }else{
            timecursor.style.left = x+'px';
            }


          var step = locDuration/progresswidth;
          //console.log(x+":"+step);
          console.log("позиция во времени: "+x*step+" длина трека duration "+locDuration);
      audio.currentTime = x*step;
      //timecursor.style.left = x-40+'px';
    }
    /*************************************/
    function changeVolume(e, obj){
      if (window.event && !e) e=window.event;
      var ref=e.target||e.srcElement;

       var locDuration = 0;
      if (audio.duration) {
        locDuration = audio.duration;
        } else {
          audio.onloadedmetadata = function() {
            locDuration = audio.duration;
            }
          }

       //var e = window.event;
       //e.target = e.srcElement;
       var x = e.offsetX==undefined?e.layerX:e.offsetX;
       var y = e.offsetY==undefined?e.layerY:e.offsetY;


      var volumecursor = document.getElementById('volumecursor');
      var volumecursorwidth = 0;
      volumecursorwidth = volumecursor.offsetWidth;

      var progresswidth = 0;
var volumecontrolcontainer = document.getElementById('volumecontrolcontainer');
progresswidth = volumecontrolcontainer.offsetWidth;


      if((x-volumecursorwidth)<0){x=0;volumecursor.style.left = x+'px';}else if((x+volumecursorwidth)>=progresswidth){x=progresswidth-volumecursorwidth;volumecursor.style.left = x+'px';}else{volumecursor.style.left = x+'px';}


          var step = 1.0/progresswidth;
          var currentvolume = audio.volume;
          //console.log(currentvolume+"-"+x+":"+step);
          audio.volume = x*step;


        //volumecursor.innerHTML = "11";
        //console.log(audio.volume);
      //audio.currentTime = x*step;
      //timecursor.style.left = x-40+'px';
    }

</script>

<table id="playerstyle">
    <tr>
        <td id="buttons">

            <div id="repeatsong" class="repeatsongoff" title="[REPEATSONG]" onclick="repeatSongSwitch();"></div>
            <div id="repeatplaylist" class="repeatplaylistoff" title="[REPEATPLAYLIST]" onclick="repeatPlaylistSwitch();"></div>
            <div id="previoussong" class="previoussong" title="[PREVIOUSSONG]" onclick="previousSong();"></div>
            <div id="nextsong" class="nextsong" title="[NEXTSONG]" onclick="nextSong();"></div>
            <div id="stopsong" class="stopsong" title="[STOPSONG]" onclick="stopSong();"></div>
            <div id="volumesong" class="volumeon" title="[VOLUMESONG]" onclick="volumeSwitch();"></div>
            <div id="playpausesong" class="playpaudefault" title="[PLAYPAUSESONG]" onclick="playpauseSwitch();"></div>
            <div id="randomsong" class="randomsong" title="[RANDOMSONG]" onclick="randomSong();"></div>
            <div class=""></div>
        </td>
    </tr>
    <tr>
        <td id="timeline">
            <table id="timecont">
                <tr>
                    <td id="currenttimetd"><div id="currenttime" class="currenttime" title="Время">00:00</div></td>
                    <td id="timelinecontainertd"><div id="timelinecontainer" class="timelinecontainer" onclick="changePosition(event,this)" style="z-index: 1;"><div style="z-index: 2;" id="timecursor" ></div></div></td>
                    <td id="durationtimetd"><div id="durationtime" class="durationtime" title="Время">00:00</div></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td id="volumecontrol">
            <table id="volcont">
                <tr>
                    <td id="volumecontrolcontainertd"><div id="volumecontrolcontainer" class="volumecontrolcontainer" onclick="changeVolume(event,this)"><div id="volumecursor" ></div></div></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td>
            <table id="songnavigation">
                <tr>
                    <td id="prevsongtd"><div style="width: 200px" id="prevsongdiv" class="" title=""></div></td>
                    <td id="cursongtd"><div id="cursongdiv" class="" title=""></div></td>
                    <td id="nextsongtd"><div style="width: 200px" id="nextsongdiv" class="" title=""></div></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
